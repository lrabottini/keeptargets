export const handler = async (event) => {
    // TODO implement
    const response = {
      statusCode: 200,
      body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
  };
  const axios = require('axios');
  
  exports.handler = async (event) => {
      try {
          // URL da API da OpenAI
          const url = process.env.OPEN_AI_URL;
  
          // Verifica se os bodies foram passados no evento
          const bodies = event.bodies;
          if (!Array.isArray(bodies) || bodies.length === 0) {
              return {
                  statusCode: 400,
                  body: JSON.stringify({ error: "A lista de bodies é necessária e deve conter pelo menos um item." }),
              };
          }
  
          // Cabeçalhos da requisição
          const headers = {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${process.env.OPENAI_API_KEY}` // Certifique-se de configurar esta variável de ambiente
          };
  
          // Fazendo as chamadas em paralelo e aguardando todas as respostas
          const results = await Promise.allSettled(
              bodies.map(body => axios.post(url, body, { headers }))
          );
  
          // Processando as respostas
          const processedResults = results.map(result => {
              if (result.status === 'fulfilled') {
                  return { success: true, data: result.value.data.choices[0].message.content };
              } else {
                  return { success: false, error: result.reason.message };
              }
          });
  
          // Retornando todos os resultados juntos
          return {
              statusCode: 200,
              body: JSON.stringify({ results: processedResults }),
          };
      } catch (error) {
          console.error("Erro ao acessar a API da OpenAI:", error);
          return {
              statusCode: 500,
              body: JSON.stringify({ error: "Erro ao acessar a API da OpenAI", details: error.message }),
          };
      }
  };
  