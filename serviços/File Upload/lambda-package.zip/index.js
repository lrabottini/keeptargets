// Importa os pacotes necessários
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner"); // Para gerar URLs pré-assinadas

// Cria um cliente S3 com as credenciais e região necessárias
const s3Client = new S3Client({
  region: 'us-east-1', // Substitua pela sua região
});

exports.handler = async (event) => {
  // Extrai o nome e tipo do arquivo do corpo da requisição
  const { fileName, fileType } = JSON.parse(event.body);

  const bucketName = 'YOUR_BUCKET_NAME'; // Substitua pelo nome do seu bucket
  const expiresIn = 3600; // Tempo de expiração da URL pré-assinada (em segundos)

  // Valida se o arquivo é do tipo PDF
  if (fileType !== 'application/pdf') {
    return {
      statusCode: 400,
      body: JSON.stringify({
        message: 'Somente arquivos PDF são permitidos.',
      }),
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*", // Permite CORS
      },
    };
  }

  // Parâmetros para o upload do arquivo no S3
  const params = {
    Bucket: bucketName,
    Key: fileName, // O nome do arquivo será usado como chave
    ContentType: fileType, // Tipo de conteúdo (application/pdf)
  };

  try {
    // Cria o comando PutObject para o S3
    const command = new PutObjectCommand(params);

    // Gera a URL pré-assinada para o upload do arquivo
    const url = await getSignedUrl(s3Client, command, { expiresIn });

    // Retorna a URL pré-assinada gerada para o cliente
    return {
      statusCode: 200,
      body: JSON.stringify({
        presignedUrl: url, // Retorna a URL pré-assinada
      }),
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*", // Permite CORS
      },
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: 'Erro ao gerar URL pré-assinada',
        error: error.message,
      }),
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*", // Permite CORS
      },
    };
  }
};
